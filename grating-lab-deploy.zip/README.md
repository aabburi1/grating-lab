# Grating Lab

A Streamlit application for PHYS1291 Experiment 7 (diffraction grating).

## Run locally

```bash
python -m pip install -r requirements.txt
streamlit run grating_lab.py
```

## Deploy with Streamlit Community Cloud

1. Create a GitHub repository named `grating-lab`.
2. Upload `grating_lab.py`, `requirements.txt`, and this README.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select your repository and branch (`main`).
5. Set the main file path to `grating_lab.py`, then deploy.

## Notes

- The model assumes normal incidence and a screen perpendicular to the central beam.
- Screen spot brightness and colour are illustrative only.
- Record measurement uncertainties separately; the displayed spread is not a complete uncertainty budget.

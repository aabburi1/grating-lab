"""
Grating Lab — PHYS1291 Experiment 7
Run:
    pip install -r requirements.txt
    streamlit run grating_lab.py

Deploy:
    Push grating_lab.py and requirements.txt to a GitHub repository,
    then deploy that repository with Streamlit Community Cloud.
"""

import math
from typing import Optional

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="Grating Lab", page_icon="🔴", layout="wide")

# ------------------------------- Physics ------------------------------------
INCH_CM = 2.54

UNITS = {
    "lines per inch (LPI)": ("LPI", 1 / INCH_CM),
    "lines per mm": ("lines/mm", 10.0),
    "lines per cm": ("lines/cm", 1.0),
}

LASERS = {
    "670 nm (lab manual)": 670.0,
    "650 nm (common red pointer)": 650.0,
    "635 nm (red diode)": 635.0,
    "632.8 nm (He-Ne)": 632.8,
    "532 nm (green pointer)": 532.0,
    "Custom": None,
}


def pitch_um(lines_per_cm: float) -> float:
    return 1e4 / lines_per_cm


def max_order(lines_per_cm: float, wavelength_nm: float) -> int:
    """Largest integer n for which n*lambda/d < 1."""
    ratio = 1e7 / (lines_per_cm * wavelength_nm)
    # Subtract a tiny tolerance so a mathematically exact grazing order is excluded.
    return max(0, math.ceil(ratio - 1e-12) - 1)


def order_geometry(
    lines_per_cm: float, wavelength_nm: float, order: int, distance_cm: float
):
    """Return (angle_deg, sin(angle), screen_y_cm), or None if unavailable."""
    sine = order * wavelength_nm * 1e-7 * lines_per_cm
    if sine <= 0 or sine >= 1:
        return None
    angle = math.asin(sine)
    return math.degrees(angle), sine, distance_cm * math.tan(angle)


def wavelength_rgb(wavelength_nm: float):
    """Approximate visible colour; used only for illustration."""
    wl = wavelength_nm
    if 380 <= wl < 440:
        rgb = (-(wl - 440) / 60, 0, 1)
    elif 440 <= wl < 490:
        rgb = (0, (wl - 440) / 50, 1)
    elif 490 <= wl < 510:
        rgb = (0, 1, -(wl - 510) / 20)
    elif 510 <= wl < 580:
        rgb = ((wl - 510) / 70, 1, 0)
    elif 580 <= wl < 645:
        rgb = (1, -(wl - 645) / 65, 0)
    elif 645 <= wl <= 780:
        rgb = (1, 0, 0)
    else:
        return (180, 180, 180)
    factor = 0.3 + 0.7 * (wl - 380) / 40 if wl < 420 else (
        0.3 + 0.7 * (780 - wl) / 80 if wl > 700 else 1
    )
    return tuple(round(255 * max(0, min(1, c * factor))) for c in rgb)


def prediction_table(lines_per_cm, wavelength_nm, tolerance_nm, distance_cm, orders_to_show):
    rows = []
    highest = min(max_order(lines_per_cm, wavelength_nm), orders_to_show)
    for order in range(1, highest + 1):
        centre = order_geometry(lines_per_cm, wavelength_nm, order, distance_cm)
        low = order_geometry(lines_per_cm, max(1, wavelength_nm - tolerance_nm), order, distance_cm)
        high = order_geometry(lines_per_cm, wavelength_nm + tolerance_nm, order, distance_cm)
        rows.append({
            "Order n": order,
            "Angle φ (°)": round(centre[0], 3),
            "sin φ": round(centre[1], 5),
            "Position Y (cm)": round(centre[2], 3),
            "Y range from wavelength tolerance (cm)": (
                f"{low[2]:.2f}–{high[2]:.2f}" if low and high else "outside model range"
            ),
        })
    return pd.DataFrame(rows)


def screen_figure(lines_per_cm, wavelength_nm, distance_cm, orders_to_show):
    rgb = wavelength_rgb(wavelength_nm)
    xs, orders = [0.0], [0]
    for order in range(1, min(max_order(lines_per_cm, wavelength_nm), orders_to_show) + 1):
        y = order_geometry(lines_per_cm, wavelength_nm, order, distance_cm)[2]
        xs.extend([-y, y])
        orders.extend([order, order])

    fig = go.Figure()
    for size, opacity in [(34, 0.10), (20, 0.22), (9, 0.85)]:
        fig.add_trace(go.Scatter(
            x=xs, y=[0] * len(xs), mode="markers",
            marker=dict(size=size, color=f"rgba({rgb[0]},{rgb[1]},{rgb[2]},{opacity})"),
            hoverinfo="skip", showlegend=False,
        ))
    fig.add_trace(go.Scatter(
        x=xs, y=[0.65] * len(xs), mode="text",
        text=[str(n) for n in orders],
        textfont=dict(size=11, color="#9FB0C0"),
        hoverinfo="skip", showlegend=False,
    ))
    span = max([abs(x) for x in xs] + [1]) * 1.25
    fig.update_layout(
        height=145, margin=dict(l=12, r=12, t=8, b=28),
        paper_bgcolor="#0A1624", plot_bgcolor="#0A1624",
        xaxis=dict(range=[-span, span], ticksuffix=" cm", showgrid=False,
                   zeroline=False, tickfont=dict(color="#9FB0C0")),
        yaxis=dict(range=[-1, 1], visible=False),
        font=dict(color="#DCE5ED"),
    )
    return fig


def analyse_readings(readings, grating_map, wavelength_nm, default_distance_cm):
    results = []
    for _, row in readings.iterrows():
        label = row.get("Grating")
        raw_order = row.get("Order n")
        if label not in grating_map or pd.isna(raw_order):
            continue
        if float(raw_order) < 1 or not float(raw_order).is_integer():
            continue

        left, right = row.get("Y left (cm)"), row.get("Y right (cm)")
        ys = [float(v) for v in (left, right) if pd.notna(v)]
        if not ys or any(y <= 0 for y in ys):
            continue

        raw_distance = row.get("D (cm, optional)")
        distance = (
            float(raw_distance)
            if pd.notna(raw_distance) and float(raw_distance) > 0
            else default_distance_cm
        )
        order = int(raw_order)
        density = grating_map[label]
        y_mean = sum(ys) / len(ys)
        sine = math.sin(math.atan(y_mean / distance))
        measured_lambda = (1e7 / density) * sine / order
        measured_density = sine / (order * wavelength_nm * 1e-7)
        expected = order_geometry(density, wavelength_nm, order, distance)

        results.append({
            "Grating": label,
            "Order n": order,
            "Y mean (cm)": y_mean,
            "D (cm)": distance,
            "sin φ": sine,
            "λ from reading (nm)": measured_lambda,
            "Density from reading (lines/cm)": measured_density,
            "Y expected (cm)": expected[2] if expected else float("nan"),
            "Order physically available?": expected is not None,
            "_density_lines_cm": density,
        })
    return pd.DataFrame(results)


def fit_per_grating(results, reference_wavelength_nm):
    rows = []
    for label, group in results.groupby("Grating", sort=False):
        density = group["_density_lines_cm"].iloc[0]
        denominator = (group["Order n"] ** 2).sum()
        slope = (group["Order n"] * group["sin φ"]).sum() / denominator
        fitted_lambda = (1e7 / density) * slope
        fitted_density = slope / (reference_wavelength_nm * 1e-7)
        rows.append({
            "Grating": label,
            "Readings": len(group),
            "Fitted λ (nm)": fitted_lambda,
            "λ error (%)": (fitted_lambda - reference_wavelength_nm) / reference_wavelength_nm * 100,
            "Fitted density (lines/cm)": fitted_density,
            "Density error (%)": (fitted_density - density) / density * 100,
            "slope": slope,
            "_density_lines_cm": density,
        })
    return pd.DataFrame(rows)


# ------------------------------- Sidebar ------------------------------------
with st.sidebar:
    st.header("Experiment setup")
    unit_name = st.selectbox("Grating density unit", list(UNITS), index=0)
    unit_short, unit_factor = UNITS[unit_name]

    laser_name = st.selectbox("Laser wavelength", list(LASERS), index=0)
    if LASERS[laser_name] is None:
        wavelength = st.number_input(
            "Wavelength (nm)", min_value=300.0, max_value=1100.0,
            value=650.0, step=1.0
        )
    else:
        wavelength = LASERS[laser_name]

    tolerance = st.number_input(
        "Wavelength tolerance ± (nm)", min_value=0.0, max_value=50.0,
        value=10.0, step=1.0
    )
    distance = st.number_input(
        "Grating-to-screen distance D (cm)", min_value=1.0,
        max_value=2000.0, value=100.0, step=5.0
    )
    spot_diameter = st.number_input(
        "Approximate spot diameter (cm)", min_value=0.01,
        max_value=10.0, value=0.3, step=0.05
    )
    orders_to_show = st.slider("Maximum orders to display", 1, 10, 3)

    st.subheader(f"Your gratings ({unit_short})")
    grating_df = st.data_editor(
        pd.DataFrame({"Density": [200.0, 500.0, 1000.0, 1200.0]}),
        num_rows="dynamic", hide_index=True, key="grating_editor",
        column_config={
            "Density": st.column_config.NumberColumn(
                f"Density ({unit_short})", min_value=0.001, format="%.3f", required=True
            )
        },
    )

valid_densities = []
for value in grating_df["Density"].dropna():
    value = float(value)
    if math.isfinite(value) and value > 0 and value not in valid_densities:
        valid_densities.append(value)

if not valid_densities:
    st.warning("Add at least one positive grating density in the sidebar.")
    st.stop()

grating_map = {f"{value:g}": value * unit_factor for value in valid_densities}
labels = list(grating_map)

# ------------------------------- Main page ---------------------------------
st.title("🔴 Grating Lab")
st.caption(
    "Predict diffraction orders, enter experimental measurements, "
    "and compare the measured wavelength and grating density."
)

tab_predict, tab_readings, tab_sources = st.tabs(
    ["Predictions", "Experimental readings", "Theory & sources"]
)

with tab_predict:
    st.subheader(f"Predictions · λ = {wavelength:g} nm · D = {distance:g} cm")
    summary_rows = []
    for label, density in grating_map.items():
        first = order_geometry(density, wavelength, 1, distance)
        summary_rows.append({
            "Grating": f"{label} {unit_short}",
            "Spacing d (µm)": pitch_um(density),
            "Density (lines/cm)": density,
            "Maximum order": max_order(density, wavelength),
            "First-order angle (°)": first[0] if first else None,
            "First-order position (cm)": first[2] if first else None,
        })
    summary = pd.DataFrame(summary_rows)
    st.dataframe(summary.round(3), hide_index=True, use_container_width=True)
    st.download_button(
        "Download prediction table (CSV)",
        summary.to_csv(index=False).encode("utf-8"),
        "grating_predictions.csv", "text/csv"
    )

    st.subheader("Diffraction pattern on the screen")
    st.caption("Illustrative spot brightness; horizontal positions are to scale.")
    for label, density in grating_map.items():
        with st.container(border=True):
            maximum = max_order(density, wavelength)
            st.markdown(
                f"**{label} {unit_short}** · d = {pitch_um(density):.3f} µm · "
                f"{maximum} observable order(s) on each side"
            )
            if maximum == 0:
                st.warning("No non-zero diffraction order is possible for these settings.")
                continue
            st.plotly_chart(
                screen_figure(density, wavelength, distance, orders_to_show),
                use_container_width=True,
                config={"displayModeBar": False},
            )
            table = prediction_table(density, wavelength, tolerance, distance, orders_to_show)
            st.dataframe(table, hide_index=True, use_container_width=True)
            first_y = order_geometry(density, wavelength, 1, distance)[2]
            if first_y < 1.5 * spot_diameter:
                angle = math.radians(order_geometry(density, wavelength, 1, distance)[0])
                suggested_distance = 1.5 * spot_diameter / math.tan(angle)
                st.info(
                    f"The first-order spot is close to the centre ({first_y:.2f} cm). "
                    f"For a separation of about 1.5 spot diameters, the model suggests "
                    f"D ≈ {suggested_distance:.1f} cm."
                )

with tab_readings:
    st.subheader("Enter your experimental measurements")
    st.caption(
        "Enter the distance from the central maximum to each side's spot. "
        "At least one side is required. Leave the row-specific D blank to use the sidebar distance."
    )

    # Rebuild defaults when labels change, while preserving matching existing rows.
    if "reading_data" not in st.session_state:
        st.session_state["reading_data"] = pd.DataFrame(columns=[
            "Grating", "Order n", "Y left (cm)", "Y right (cm)", "D (cm, optional)"
        ])

    old = st.session_state["reading_data"].copy()
    old_labels = set(old["Grating"].dropna()) if "Grating" in old else set()
    if not old.empty:
        old = old[old["Grating"].isin(labels)]
    if old.empty:
        old = pd.DataFrame([{
            "Grating": label, "Order n": 1, "Y left (cm)": None,
            "Y right (cm)": None, "D (cm, optional)": None
        } for label in labels])
    elif set(labels) != old_labels:
        present = set(old["Grating"].dropna())
        additions = [{
            "Grating": label, "Order n": 1, "Y left (cm)": None,
            "Y right (cm)": None, "D (cm, optional)": None
        } for label in labels if label not in present]
        if additions:
            old = pd.concat([old, pd.DataFrame(additions)], ignore_index=True)

    edited = st.data_editor(
        old, num_rows="dynamic", hide_index=True, key="reading_editor",
        column_config={
            "Grating": st.column_config.SelectboxColumn(
                f"Grating ({unit_short})", options=labels, required=True
            ),
            "Order n": st.column_config.NumberColumn(
                "Order n", min_value=1, max_value=50, step=1, format="%d"
            ),
            "Y left (cm)": st.column_config.NumberColumn(
                "Y left (cm)", min_value=0.001, step=0.01, format="%.2f"
            ),
            "Y right (cm)": st.column_config.NumberColumn(
                "Y right (cm)", min_value=0.001, step=0.01, format="%.2f"
            ),
            "D (cm, optional)": st.column_config.NumberColumn(
                "D (cm, optional)", min_value=1.0, step=1.0, format="%.1f"
            ),
        },
    )
    st.session_state["reading_data"] = edited.copy()

    results = analyse_readings(edited, grating_map, wavelength, distance)
    if results.empty:
        st.info("Enter a grating, integer order, and at least one positive spot distance.")
    else:
        invalid_orders = results[~results["Order physically available?"]]
        if not invalid_orders.empty:
            st.warning(
                "At least one measured order is not predicted to exist for the selected "
                "grating and wavelength. Check the grating label, order number, and alignment."
            )

        valid_results = results[results["Order physically available?"]].copy()
        if valid_results.empty:
            st.info("No physically valid rows are available for the fit yet.")
        else:
            fits = fit_per_grating(valid_results, wavelength)
            mean_lambda = valid_results["λ from reading (nm)"].mean()
            spread = (
                valid_results["λ from reading (nm)"].std()
                if len(valid_results) > 1 else float("nan")
            )
            c1, c2, c3 = st.columns(3)
            c1.metric("Mean measured wavelength", f"{mean_lambda:.2f} nm")
            c2.metric("Reading spread (sample SD)", "—" if pd.isna(spread) else f"{spread:.2f} nm")
            c3.metric("Mean wavelength error", f"{(mean_lambda-wavelength)/wavelength*100:+.2f}%")

            st.subheader("Individual reading results")
            display = valid_results.drop(columns=["_density_lines_cm"]).copy()
            display["Density from reading (" + unit_short + ")"] = (
                display["Density from reading (lines/cm)"] / unit_factor
            )
            display = display.drop(columns=["Density from reading (lines/cm)"])
            st.dataframe(display.round(3), hide_index=True, use_container_width=True)

            st.subheader("Least-squares fit by grating")
            st.caption(
                "The fit is constrained through the origin: sin(φ) = slope × n, "
                "where slope = λ/d."
            )
            fit_display = fits[[
                "Grating", "Readings", "Fitted λ (nm)", "λ error (%)",
                "Fitted density (lines/cm)", "Density error (%)"
            ]].copy()
            fit_display["Fitted density (" + unit_short + ")"] = (
                fits["Fitted density (lines/cm)"] / unit_factor
            )
            fit_display = fit_display.drop(columns=["Fitted density (lines/cm)"])
            fit_display["Stated density (" + unit_short + ")"] = (
                fits["_density_lines_cm"] / unit_factor
            )
            st.dataframe(fit_display.round(3), hide_index=True, use_container_width=True)

            figure = go.Figure()
            max_n = float(valid_results["Order n"].max()) + 0.5
            for _, fit in fits.iterrows():
                label = fit["Grating"]
                group = valid_results[valid_results["Grating"] == label]
                figure.add_trace(go.Scatter(
                    x=group["Order n"], y=group["sin φ"], mode="markers",
                    name=f"{label}: readings", marker=dict(size=9)
                ))
                figure.add_trace(go.Scatter(
                    x=[0, max_n], y=[0, fit["slope"] * max_n],
                    mode="lines", name=f"{label}: fitted"
                ))
                theoretical_slope = wavelength * 1e-7 * fit["_density_lines_cm"]
                figure.add_trace(go.Scatter(
                    x=[0, max_n], y=[0, theoretical_slope * max_n],
                    mode="lines", name=f"{label}: theoretical",
                    line=dict(dash="dot")
                ))
            figure.update_layout(
                template="plotly_white", height=430,
                xaxis_title="Diffraction order n", yaxis_title="sin(φ)",
                margin=dict(l=10, r=10, t=15, b=10),
                legend=dict(orientation="h", y=-0.25)
            )
            figure.update_xaxes(dtick=1, rangemode="tozero")
            figure.update_yaxes(rangemode="tozero")
            st.plotly_chart(figure, use_container_width=True)

            export = valid_results.drop(columns=["_density_lines_cm"])
            st.download_button(
                "Download analysed readings (CSV)",
                export.to_csv(index=False).encode("utf-8"),
                "grating_readings_analysis.csv", "text/csv"
            )

with tab_sources:
    st.subheader("Theory")
    st.latex(r"d\sin\varphi=n\lambda \qquad Y=D\tan\varphi \qquad d=\frac{1}{N}")
    st.markdown("""
- **Grating equation:** for normal incidence, adjacent slits produce constructive interference when
  the path difference is an integer multiple of the wavelength.
- **Screen position:** the geometry gives `tan(φ) = Y/D`.
- **Grating spacing:** `d = 1/N`, where N is the number of lines per unit length.
- **Maximum order:** the largest integer order satisfying `nλ/d < 1`.
- **Unit conversion:** 1 inch = 2.54 cm exactly; lines/mm × 10 = lines/cm.
""")
    st.subheader("Assumptions and limitations")
    st.markdown("""
- The laser is assumed to strike the grating normally.
- The screen is assumed perpendicular to the central beam, and D is measured from the grating to the screen.
- The screen-position calculation uses the far-field grating equation plus straight-line screen geometry.
- Spot brightness and colour in the screen illustration are schematic, not intensity predictions.
- The wavelength tolerance band represents wavelength uncertainty only; it does not include uncertainty in D, Y, alignment, or grating density.
- A fit through the origin assumes the central maximum is correctly identified and the angle measurements have no systematic offset.
""")
    st.subheader("Experimental accuracy")
    st.markdown("""
1. Measure D from the grating plane to the screen.
2. Measure left and right distances from the central maximum to corresponding orders.
3. Keep the grating perpendicular to the incident beam.
4. Use several diffraction orders where clearly visible.
5. Record uncertainties in D and Y separately; the displayed wavelength spread is not a full uncertainty analysis.
""")
